//
// Created by ruben on 6/10/19.
//

#ifndef AGREGACION_TIPOS_H
#define AGREGACION_TIPOS_H

#include <string>
using namespace std;
// Definiendo alias
using TipoEntero = int;
using TipoCaracter = char;
using TipoString = string;

#endif //AGREGACION_TIPOS_H
