#include "Menu.h"

int main() {
    Menu menu;
    menu.ejecutar();
    return 0;
}